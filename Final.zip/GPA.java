/**
 * 
 */
/**
 * 
 */
public class GPA implements Comparable<GPA>{

	private String name;
	private String address;
	private Double gpa;
	
	public GPA(Double gpa, String name, String address) {
		this.gpa = gpa;
		this.name = name;
		this.address = address;
	}
	
	public String getN() {
		return name;
	}
	
	public void setN(String name) {
		this.name = name;
	}
	
	public String getA() {
		return address;
	}
	
	public void setA(String address) {
		this.address = address;
	}
	
	public Double getG() {
		return gpa;
	}
	
	public void setG(Double gpa) {
		this.gpa = gpa;
	}
	
	@Override
	public int compareTo(GPA o) {
		// TODO Auto-generated method stub
		return getN().compareTo(o.getN());
	}
	
	public String toString() {
		return "Name: " + name + "\naddress: " + address + "\nGPA: " + gpa;
	}
}