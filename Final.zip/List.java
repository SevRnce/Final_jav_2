import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class List {	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		LinkedList<GPA> linkL = new LinkedList<GPA>();
		
		while (true) {
			String check;
			Double gpa = 0.0;
			String name = null;
			String address = null;
			int count = 1;
			System.out.println("Would you like to add to the student list? (Y/N)");
			check = scan.nextLine().trim().toLowerCase();
			
			if (check.equals("y")) {
				for (int i=0; i<count; i++) {
					System.out.print("Enter Name: ");
					name = scan.nextLine();
					System.out.print("Enter Address: ");
					address = scan.nextLine();
					try {
						int c = 1;
						for (int x=0; x<c; x++) {
							System.out.print("Enter GPA: ");
							gpa = scan.nextDouble();
							if (gpa > 4.0) {
								count++;
								System.out.println("Error, enter a GPA below or at 4.0.");
								scan.nextLine();
							}
							else if (gpa < 0) {
								count++;
								System.out.println("Error, enter a GPA above 0.");
								scan.nextLine();
							}
						}
					} catch(Exception e) {
						count++;
						System.out.println("Invalid input, try again.");
						scan.nextLine();
					}
				}
					GPA o = new GPA(gpa, address, name);
					linkL.add(o);
					scan.nextLine();
			}
			else if (check.equals("n")) {
				break;
			}
			else {
				System.out.println("Invalid input, please answer Y for yes or N for no.");
				scan.nextLine();
			}
		}
		
		Collections.sort(linkL);
		Iterator<GPA> it = linkL.iterator();
		try {
			FileWriter writer = new FileWriter("Students.txt");
			while (it.hasNext()) {
				writer.write(it.next().toString()+"\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		scan.close();
	}
}